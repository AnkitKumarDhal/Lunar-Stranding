from bisect import bisect_right
from typing import List, Optional

from .compat import APIRouter, HTTPException, BaseModel

router = APIRouter(prefix="/api/minigames", tags=["food-production"])


class GreenhouseTask:
    def __init__(self, name, start_hour, end_hour, power_kw, hp_gain):
        self.name = name
        self.start = start_hour
        self.end = end_hour
        self.power_kw = power_kw
        self.hp_gain = hp_gain


class GreenhouseTaskInput(BaseModel):
    name: str
    start_hour: float
    end_hour: float
    power_kw: float
    hp_gain: float


class FoodProductionRequest(BaseModel):
    available_tasks: List[GreenhouseTaskInput]
    selected_tasks: List[str]
    current_hp: float = 100.0
    daily_hp_drain: float = 30.0
    bus_limit_kw: float = 5.0
    session_id: Optional[str] = "default"


def solve_best_schedule(tasks):
    """
    Find the maximum HP gain from non-overlapping greenhouse tasks.

    Returns:
        max_hp_gain, selected_optimal_tasks
    """
    if not tasks:
        return 0, []

    sorted_tasks = sorted(tasks, key=lambda task: task.end)
    end_hours = [task.end for task in sorted_tasks]

    n = len(sorted_tasks)
    dp = [0] * (n + 1)

    for i, current in enumerate(sorted_tasks, start=1):
        previous_count = bisect_right(end_hours, current.start, 0, i - 1,)
        take = current.hp_gain + dp[previous_count]
        skip = dp[i - 1]
        dp[i] = max(take, skip)

    # Reconstruct the optimal schedule.
    chosen_tasks = []
    i = n

    while i > 0:
        current = sorted_tasks[i - 1]
        previous_count = bisect_right(end_hours, current.start, 0, i - 1,)

        if current.hp_gain + dp[previous_count] >= dp[i - 1]:
            chosen_tasks.append(current)
            i = previous_count
        else:
            i -= 1

    chosen_tasks.reverse()

    return dp[n], chosen_tasks


def simulate_day(all_tasks, player_chosen_names, current_hp, daily_hp_drain=30, bus_limit_kw=5.0,):
    """
    Simulate one day of greenhouse operations.

    Checks:
    1. Total simultaneous power consumption.
    2. HP gained from selected tasks.
    3. Daily survival drain.
    """

    task_map = {task.name: task for task in all_tasks}

    chosen = [task_map[name] for name in player_chosen_names]
    chosen.sort(key=lambda task: task.start)

    # Create start and end events.
    events = []

    for task in chosen:
        events.append((task.start, 1, task))
        events.append((task.end, 0, task))

    # End events are processed before start events
    # at the same hour.
    events.sort(key=lambda event: (event[0], event[1]))
    active = {}

    for _, event_type, task in events:

        if event_type == 0:
            active.pop(task.name, None)
            continue

        active[task.name] = task

        combined_kw = round(
            sum(active_task.power_kw for active_task in active.values()), 1,)

        if combined_kw > bus_limit_kw:
            penalty_hp = max(0, current_hp - 25)

            active_names = ", ".join(active)

            return {
                "status": "POWER_OVERLOAD",
                "message": (
                    f"Overload ({combined_kw} kW > "
                    f"{bus_limit_kw} kW limit) while running "
                    f"{active_names}."
                ),
                "new_hp": penalty_hp,
                "survived_day": penalty_hp > 0,
            }

    # Calculate player HP gain.
    gained_hp = sum(task.hp_gain for task in chosen)

    # Calculate optimal schedule.
    max_possible_hp, best_tasks = solve_best_schedule(all_tasks)

    new_hp = min(100, max(0, current_hp - daily_hp_drain + gained_hp,),)

    return {
        "status": "OK",
        "hp_gained": gained_hp,
        "max_possible_hp_gain": max_possible_hp,
        "daily_drain": daily_hp_drain,
        "new_hp": new_hp,
        "survived_day": new_hp > 0,
        "optimal_plan": [
            task.name for task in best_tasks
        ],
    }


@router.post("/food-production")
def food_production(req: FoodProductionRequest):

    if not 0 <= req.current_hp <= 100:
        raise HTTPException(
            status_code=400, detail="current_hp must be between 0 and 100",)
    if req.daily_hp_drain < 0:
        raise HTTPException(
            status_code=400, detail="daily_hp_drain cannot be negative",)
    if req.bus_limit_kw <= 0:
        raise HTTPException(
            status_code=400, detail="bus_limit_kw must be positive",)

    names = [task.name for task in req.available_tasks]

    if len(names) != len(set(names)):
        raise HTTPException(
            status_code=400, detail="Task names must be unique",)

    for task in req.available_tasks:

        if (task.start_hour < 0 or task.end_hour > 24 or task.end_hour <= task.start_hour):
            raise HTTPException(status_code=400, detail=(
                f"Task '{task.name}' must have " "a valid time window within 0-24 hours"),)

        if task.power_kw < 0 or task.hp_gain < 0:
            raise HTTPException(status_code=400, detail=(
                f"Task '{task.name}' power_kw " "and hp_gain cannot be negative"),)

    if len(req.selected_tasks) != len(set(req.selected_tasks)):
        raise HTTPException(
            status_code=400, detail="A task cannot be selected more than once",)

    unknown = sorted(set(req.selected_tasks) - set(names))

    if unknown:
        raise HTTPException(status_code=400, detail=(
            f"Unknown selected tasks: " f"{', '.join(unknown)}"),)

    tasks = [GreenhouseTask(task.name, task.start_hour, task.end_hour,
                            task.power_kw, task.hp_gain,) for task in req.available_tasks]

    return simulate_day(tasks, req.selected_tasks, req.current_hp, daily_hp_drain=req.daily_hp_drain, bus_limit_kw=req.bus_limit_kw,)
