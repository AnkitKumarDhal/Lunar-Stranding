from collections import deque
from typing import Dict, List, Optional
from .compat import APIRouter, HTTPException, BaseModel

router = APIRouter(prefix="/api/minigames", tags=["crater-traverse"],)


class CraterTraverseRequest(BaseModel):
    graph: Dict[str, List[str]]
    start_node: str = "Crater_Alpha"
    player_path: List[str]
    target_node: Optional[str] = None
    session_id: Optional[str] = "default"


def bfs_shortest_path(graph, start, target):
    """Legacy helper: shortest path between two nodes."""

    if start == target:
        return 0, [start]

    queue = deque([(start, [start])])
    visited = {start}

    while queue:
        current, path = queue.popleft()
        if current == target:
            return len(path) - 1, path
        for neighbor in graph.get(current, []):
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append((neighbor, path + [neighbor]))

    return None, []


def bfs_reachable(graph, start):
    queue = deque([start])
    visited = {start}
    order = []

    while queue:
        current = queue.popleft()
        order.append(current)

        for neighbor in graph.get(current, []):
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(neighbor)

    return order


def bfs_min_steps_to_all(graph, start):
    """
    Find the fewest edge traversals needed
    to visit every graph node.

    BFS state:
        (current_node, visited_bitmask)
    """

    nodes = sorted(graph)
    if len(nodes) <= 1:
        return 0, [start]
    node_to_idx = {name: index for index, name in enumerate(nodes)}
    target_mask = (1 << len(nodes)) - 1
    start_mask = 1 << node_to_idx[start]
    queue = deque([(start, start_mask, [start])])
    visited_states = {(start, start_mask)}

    while queue:
        current, mask, path = queue.popleft()
        # Every node has been visited.
        if mask == target_mask:
            return len(path) - 1, path
        for neighbor in graph.get(current, []):
            next_mask = (mask | (1 << node_to_idx[neighbor]))
            state = (neighbor, next_mask)
            if state not in visited_states:
                visited_states.add(state)
                queue.append((neighbor, next_mask, path + [neighbor],))
    return None, []


def validate_player_path(graph, path, start):
    if not path:
        return False, "Path cannot be empty"

    if path[0] != start:
        return False, f"Path must start at {start}"

    for index in range(len(path) - 1):
        current = path[index]
        following = path[index + 1]
        if current not in graph:
            return False, f"Crater {current} not found on map"
        if following not in graph.get(current, []):
            return False, (f"No direct route between {current} " f"and {following}")

    return True, ""


@router.post("/crater-traverse")
def crater_traversal(req: CraterTraverseRequest):
    graph = req.graph
    start = req.start_node
    path = req.player_path

    if not graph:
        raise HTTPException(status_code=400, detail="Graph cannot be empty",)

    if start not in graph:
        raise HTTPException(status_code=400, detail=f"Start crater '{
                            start}' not found in map",)

    # Reject edges referencing nonexistent nodes.
    for crater, neighbors in graph.items():
        unknown = sorted(set(neighbors) - set(graph))

        if unknown:
            raise HTTPException(status_code=400, detail=(
                f"Crater '{crater}' references " f"unknown nodes: {', '.join(unknown)}"),)

    # Determine reachable craters.
    bfs_order = bfs_reachable(graph, start)
    total_nodes = len(graph)
    reachable_count = len(bfs_order)

    # Calculate the optimal traversal.
    opt_steps, opt_path = bfs_min_steps_to_all(graph, start,)

    optimal_info = {"path": opt_path, "steps": opt_steps,
                    "bfs_discovery_order": bfs_order, }

    # Handle disconnected graphs.
    if (opt_steps is None or reachable_count < total_nodes):
        unreachable = [crater for crater in graph if crater not in bfs_order]
        player_visited = set(path)

        return {
            "is_valid_path": False,
            "status": "DISCONNECTED",
            "optimal": optimal_info,
            "optimal_path": opt_path or [],
            "optimal_steps": opt_steps,
            "minimum_steps_required": opt_steps,
            "player_path": path,
            "player_steps": len(path) - 1 if path else 0,
            "player_steps_taken": len(path) - 1 if path else 0,
            "all_craters_covered": False,
            "total_craters": total_nodes,
            "craters_visited_count": len(player_visited.intersection(graph)),
            "unvisited_craters": unreachable,
            "efficiency_percentage": 0.0,
            "step_efficiency_percentage": 0.0,
            "message": ("Graph has disconnected craters that " "cannot be reached: " f"{', '.join(unreachable)}"),
        }

    # Validate player's path.
    is_valid, error = validate_player_path(graph, path, start,)

    if not is_valid:
        visited_count = len(set(path))

        return {
            "is_valid_path": False,
            "status": "INVALID_PATH",
            "optimal": optimal_info,
            "optimal_path": opt_path,
            "optimal_steps": opt_steps,
            "minimum_steps_required": opt_steps,
            "player_path": path,
            "player_steps": len(path) - 1 if path else 0,
            "player_steps_taken": len(path) - 1 if path else 0,
            "all_craters_covered": False,
            "total_craters": total_nodes,
            "craters_visited_count": visited_count,
            "unvisited_craters": [crater for crater in graph if crater not in set(path)],
            "efficiency_percentage": 0.0,
            "step_efficiency_percentage": 0.0,
            "message": error,
        }

    # Determine player exploration progress.
    visited_by_player = set(path)
    visited_count = len(visited_by_player)
    unvisited = [crater for crater in graph if crater not in visited_by_player]
    all_covered = not unvisited
    player_steps = len(path) - 1

    if not all_covered:
        status = "INCOMPLETE"
        efficiency = round((visited_count / total_nodes) * 50.0, 2,)
        message = (f"Incomplete exploration! You visited " f"{
                   visited_count}/{total_nodes} craters. " f"Missed: {', '.join(unvisited)}.")

    elif player_steps <= opt_steps:
        efficiency = 100.0
        status = "OPTIMAL_TRAVERSAL"
        message = (f"PERFECT TRAVERSAL! All {
                   total_nodes} " f"craters visited in the minimum possible " f"{player_steps} steps.")

    else:
        efficiency = round(min(1.0, opt_steps / player_steps) * 100.0, 2,)
        status = "SUBOPTIMAL_TRAVERSAL"
        extra = player_steps - opt_steps
        message = (f"All {total_nodes} craters visited, but " f"took {player_steps} steps " f"({
                   extra} extra steps vs optimal " f"{opt_steps}). {efficiency}% efficiency.")

    return {
        "is_valid_path": True,
        "status": status,
        "optimal": optimal_info,
        "optimal_path": opt_path,
        "optimal_steps": opt_steps,
        "minimum_steps_required": opt_steps,
        "player_path": path,
        "player_steps": player_steps,
        "player_steps_taken": player_steps,
        "all_craters_covered": all_covered,
        "total_craters": total_nodes,
        "craters_visited_count": visited_count,
        "unvisited_craters": unvisited,
        "efficiency_percentage": efficiency,
        "step_efficiency_percentage": efficiency,
        "message": message,
    }
