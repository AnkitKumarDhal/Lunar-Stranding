from typing import List
from .compat import APIRouter, BaseModel, HTTPException

router = APIRouter(prefix="/api/minigames", tags=["signal-match"])


class SignalMatchRequest(BaseModel):
    signal: List[int]
    pattern: List[int]


def rabin_karp_search(signal_list, pattern_list, d=10, q=13,):
    n = len(signal_list)
    m = len(pattern_list)

    if m == 0:
        return 0

    if m > n:
        return -1

    h = pow(d, m - 1, q)

    pattern_hash = 0
    window_hash = 0

    for i in range(m):
        pattern_hash = (d * pattern_hash + pattern_list[i]) % q
        window_hash = (d * window_hash + signal_list[i]) % q

    for start in range(n - m + 1):

        if (pattern_hash == window_hash and signal_list[start:start + m] == pattern_list):
            return start

        if start < n - m:
            window_hash = (
                d * (window_hash - signal_list[start] * h) + signal_list[start + m]) % q

    return -1


@router.post("/signal-match")
def signal_match(req: SignalMatchRequest):

    if not req.pattern:
        raise HTTPException(status_code=400, detail="pattern cannot be empty",)

    index = rabin_karp_search(req.signal, req.pattern,)

    return {
        "match_found": index >= 0,
        "index": index,
        "signal_length": len(req.signal),
        "pattern_length": len(req.pattern),
    }
