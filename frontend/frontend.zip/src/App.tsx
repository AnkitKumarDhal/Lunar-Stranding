// frontend/src/App.tsx
import { useState } from "react";
import Hud, { DailyRoutinePanel } from "./components/Hud";
import { MapBox } from "./components/MapBoxes";
import { TacticalTabletModal } from "./components/TacticalTabletModal";
import { HazardInterruptModal } from "./components/HazardInterruptModal";
import type {
  FacilityType,
  DailyTasksState,
  HazardPayload,
} from "./types/game";

const FACILITY_META: Record<
  FacilityType,
  { title: string; subtitle: string }
> = {
  solar: {
    title: "SOLAR MICROGRID ARRAY",
    subtitle: "PRIM'S MST // CABLE ROUTING & MAST CALIBRATION",
  },
  water_rover: {
    title: "WATER EXTRACTION ROVER",
    subtitle: "DIJKSTRA // LEAST-ENERGY CRATER SLOPE NAVIGATION",
  },
  mining_rover: {
    title: "PRESSURIZED MINING ROVER",
    subtitle: "BELLMAN-FORD & 0/1 KNAPSACK // EXCAVATION & CARGO",
  },
  crater_sensors: {
    title: "CRATER PERIMETER SENSORS",
    subtitle: "BREADTH-FIRST SEARCH // SENSOR NODE DEPLOYMENT",
  },
  radio: {
    title: "DEEP SPACE COMMS DISH",
    subtitle: "RABIN-KARP & HUFFMAN // SIGNAL LOCK & COMPRESSION",
  },
  greenhouse: {
    title: "HYDROPONICS GREENHOUSE",
    subtitle: "ACTIVITY SELECTION // NON-OVERLAPPING LED SCHEDULE",
  },
  garage: {
    title: "ROVER SERVICING BAY",
    subtitle: "ASSEMBLY LINE SCHEDULING // DIAGNOSTICS & REPAIR",
  },
};

export default function App() {
  // 1. UI-only state: Which facility tablet modal is currently open on screen
  const [activeFacility, setActiveFacility] = useState<FacilityType | null>(
    null,
  );

  // 2. Stateless Backend Mirror: Daily 1-click crew tasks (hydrated via backend API)
  const [dailyTasks, setDailyTasks] = useState<DailyTasksState>({
    eclss: false,
    suitport: false,
    exercise: false,
    solarHeightAdjusted: false,
  });

  // 3. Stateless Backend Mirror: Active emergency hazard payload (null when clear)
  const [activeHazard] = useState<HazardPayload | null>(null);

  // Pure action emitter: Sends daily task click to backend
  const handleToggleDailyTask = (key: keyof DailyTasksState) => {
    // Optimistic UI toggle until connected to FastAPI response
    setDailyTasks((prev) => ({ ...prev, [key]: true }));
    // TODO: fetch('/api/daily-task', { method: 'POST', body: JSON.stringify({ taskId: key }) })
  };

  // Pure action emitter: Sends emergency switch click to backend
  const handleExecuteHazardAction = (actionId: string) => {
    console.log("Dispatching emergency action to backend:", actionId);
    // TODO: fetch('/api/hazard/action', { method: 'POST', body: JSON.stringify({ actionId }) })
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-black select-none flex items-center justify-center">
      {/* MATHEMATICALLY LOCKED 16:9 MAP CONTAINER */}
      <div
        className="relative bg-[url(/moon.png)] bg-cover bg-center bg-no-repeat shadow-[0_0_50px_rgba(6,182,212,0.15)]"
        style={{
          width: "min(100vw, 100vh * (16/9))",
          height: "min(100vh, 100vw * (9/16))",
        }}
      >
        {/* Layer 1: Place-Dependent Map Markers (SVG +
