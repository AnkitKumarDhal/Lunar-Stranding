// frontend/src/types/game.ts
export type FacilityType =
  | "solar"
  | "water_rover"
  | "mining_rover"
  | "crater_sensors"
  | "radio"
  | "greenhouse"
  | "garage";

export interface HazardPayload {
  id: string;
  title: string;
  description: string;
  remainingSeconds: number; // Calculated & sent by backend
  actions: {
    id: string;
    label: string;
    completed: boolean;
  }[];
}

export interface DailyTaskItem {
  id: string;
  label: string;
  completed: boolean;
}

// Make sure this stays in frontend/src/types/game.ts
export interface DailyTasksState {
  eclss: boolean;
  suitport: boolean;
  exercise: boolean;
  solarHeightAdjusted: boolean;
}
